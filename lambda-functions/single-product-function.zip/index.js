const Airtable = require('airtable-node');

const airtable = new Airtable({ apiKey: process.env.AIRTABLE_ACCESS_TOKEN })
  .base(process.env.AIRTABLE_BASE)
  .table(process.env.AIRTABLE_TABLE);

const headers = {
  'Access-Control-Allow-Origin': '*', // Or 'http://localhost:3000'
  'Access-Control-Allow-Credentials': true,
};

exports.handler = async (event, context, cb) => {
  const { id } = event.pathParameters;
  if (id) {
    try {
      let product = await airtable.retrieve(id);
      if (product.error) {
        return {
          statusCode: 404,
          headers,
          body: `No product with id: ${id}`,
        };
      }
      product = { id: product.id, ...product.fields };
      return {
        statusCode: 200,
        headers,
        body: JSON.stringify(product),
      };
    } catch (error) {
      return {
        statusCode: 500,
        headers,
        body: `Server Error`,
      };
    }
  }
  return {
    statusCode: 400,
    headers,
    body: 'Please provide product id',
  };
};
